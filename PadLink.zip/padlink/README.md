# PadLink – phone as a PS2 controller for Linux

Android app (controller) + small Linux server that creates a real virtual gamepad
through **uinput/udev**. The PC sees it as a wired Xbox 360 pad, so RetroArch,
PCSX2, DuckStation, PPSSPP, Dolphin, Steam and any SDL game detect and auto-map it.

## Build the APK (GitHub)
1. Upload this zip to your repo, plus `.github/workflows/build.yml`
   (or upload the unzipped folder – the workflow handles both).
2. Actions → *Build PadLink APK* → download **PadLink-apk** and install it.

## Set up the Linux PC (once)
```bash
cd pc-server
chmod +x install.sh && ./install.sh
```
This installs python-evdev, loads `uinput` at boot, adds the udev rule
(`60-padlink-uinput.rules`), opens UDP 39393 in ufw/firewalld and starts
`padlink-server` as a user service. Logs: `journalctl --user -u padlink-server -f`.

Quick test without installing: `sudo python3 pc-server/padlink-server.py`

## Play
1. Phone and PC on the same Wi-Fi (or PC on the phone's hotspot).
2. Open PadLink → it scans and lists your PC → tap it.
3. Start your emulator – the pad shows up as "Microsoft X-Box 360 pad".
   Check with `evtest` or `jstest-gtk` if needed.

Several phones = several players (up to 4).

## PS2 → PC mapping
| PS2 | PC (Xbox 360) |
|---|---|
| Cross / Circle / Square / Triangle | A / B / X / Y |
| L1 / R1 | LB / RB |
| L2 / R2 | LT / RT (full press) |
| Select / Start / Analog | Back / Start / Guide |
| L3 / R3 | Left / right stick click |
| D-pad, both sticks | D-pad (hat), both sticks |

## Custom layout
Main screen → **Edit layout**: tap a control, drag to move, pinch or −/+ to resize,
Hide/Show to remove it, *Reset PS2* for the default, **Save**.
Opacity and vibration are in Settings.
