#!/usr/bin/env bash
# PadLink PC setup: python-evdev, uinput module, udev rule, firewall port, autostart service.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
PORT=39393

echo "==> python-evdev"
if python3 -c 'import evdev' 2>/dev/null; then
    echo "    already installed"
elif command -v apt-get >/dev/null; then sudo apt-get install -y python3-evdev
elif command -v dnf >/dev/null;     then sudo dnf install -y python3-evdev
elif command -v pacman >/dev/null;  then sudo pacman -S --needed --noconfirm python-evdev
elif command -v zypper >/dev/null;  then sudo zypper install -y python3-evdev
else python3 -m pip install --user evdev || python3 -m pip install --user --break-system-packages evdev
fi

echo "==> uinput kernel module (loaded now and at every boot)"
echo uinput | sudo tee /etc/modules-load.d/padlink-uinput.conf >/dev/null
sudo modprobe uinput

echo "==> udev rule"
sudo install -m 644 "$DIR/60-padlink-uinput.rules" /etc/udev/rules.d/60-padlink-uinput.rules
sudo udevadm control --reload-rules
sudo udevadm trigger --name-match=uinput 2>/dev/null || sudo udevadm trigger
if getent group input >/dev/null; then sudo usermod -aG input "$USER"; fi

echo "==> firewall (UDP $PORT)"
if command -v ufw >/dev/null && sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow $PORT/udp
fi
if command -v firewall-cmd >/dev/null && sudo firewall-cmd --state >/dev/null 2>&1; then
    sudo firewall-cmd --permanent --add-port=$PORT/udp && sudo firewall-cmd --reload
fi

echo "==> server + autostart"
install -Dm755 "$DIR/padlink-server.py" "$HOME/.local/bin/padlink-server"
install -Dm644 "$DIR/padlink-server.service" "$HOME/.config/systemd/user/padlink-server.service"
systemctl --user daemon-reload
systemctl --user enable padlink-server.service
systemctl --user restart padlink-server.service || true

echo
echo "Done. PadLink server is running and will start with your desktop session."
echo "Logs:    journalctl --user -u padlink-server -f"
echo "If it says 'No permission to use /dev/uinput', log out and back in once."
