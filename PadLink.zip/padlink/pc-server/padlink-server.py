#!/usr/bin/env python3
"""
PadLink server - turns your Android phone into a real gamepad on Linux.

Receives UDP packets from the PadLink app and creates a virtual controller via
/dev/uinput (kernel input subsystem, permissions handled by udev). The virtual
pad copies the identity and button layout of a wired Xbox 360 pad (xpad driver),
which SDL, Steam, RetroArch, PCSX2, DuckStation, PPSSPP, Dolphin etc. all
recognise and auto-map with no setup. PS2 buttons map as:

    Cross->A  Circle->B  Square->X  Triangle->Y  L1/R1->LB/RB  L2/R2->LT/RT
    Select->Back  Start->Start  Analog->Guide  L3/R3->stick clicks  D-pad->hat

One virtual pad per phone (up to --max-pads players).
"""
import argparse
import os
import select
import signal
import socket
import struct
import sys
import time

try:
    from evdev import UInput, AbsInfo, ecodes as e
except ImportError:
    sys.exit("python-evdev is missing. Install it with:\n"
             "  Debian/Ubuntu: sudo apt install python3-evdev\n"
             "  Fedora:        sudo dnf install python3-evdev\n"
             "  Arch:          sudo pacman -S python-evdev\n"
             "  other:         pip install --user evdev")

PORT = 39393
PKT = struct.Struct(">4sIIIhhhhBB")   # 26 bytes, see Net.kt
BYE = struct.Struct(">4sI")

# bit numbers - must match Btn in Layout.kt
CROSS, CIRCLE, SQUARE, TRIANGLE, L1, R1, L2, R2, SELECT, START, L3, R3, \
    UP, DOWN, LEFT, RIGHT, ANALOG = range(17)

# Same key codes the Linux xpad driver emits for an Xbox 360 pad, so the
# SDL GameControllerDB mapping for 045e:028e lines up exactly.
KEYMAP = [
    (CROSS, e.BTN_A), (CIRCLE, e.BTN_B), (SQUARE, e.BTN_X), (TRIANGLE, e.BTN_Y),
    (L1, e.BTN_TL), (R1, e.BTN_TR), (SELECT, e.BTN_SELECT), (START, e.BTN_START),
    (ANALOG, e.BTN_MODE), (L3, e.BTN_THUMBL), (R3, e.BTN_THUMBR),
]

STICK = AbsInfo(value=0, min=-32768, max=32767, fuzz=16, flat=128, resolution=0)
TRIG = AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0)
HAT = AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0)

CAPS = {
    e.EV_KEY: [k for _, k in KEYMAP],
    e.EV_ABS: [
        (e.ABS_X, STICK), (e.ABS_Y, STICK), (e.ABS_Z, TRIG),
        (e.ABS_RX, STICK), (e.ABS_RY, STICK), (e.ABS_RZ, TRIG),
        (e.ABS_HAT0X, HAT), (e.ABS_HAT0Y, HAT),
    ],
}


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


class Pad:
    def __init__(self, slot, name):
        self.slot = slot
        self.ui = UInput(CAPS, name=name, vendor=0x045E, product=0x028E,
                         version=0x0110, bustype=e.BUS_USB, phys=f"padlink/{slot}")
        self.state = {}
        self.last_seq = None
        self.last_rx = time.monotonic()
        self.neutral = True
        self.addr = None

    def apply(self, buttons, lx, ly, rx, ry, l2, r2):
        bit = lambda n: (buttons >> n) & 1
        want = {(e.EV_KEY, key): bit(b) for b, key in KEYMAP}
        want[(e.EV_ABS, e.ABS_X)] = lx
        want[(e.EV_ABS, e.ABS_Y)] = ly
        want[(e.EV_ABS, e.ABS_RX)] = rx
        want[(e.EV_ABS, e.ABS_RY)] = ry
        want[(e.EV_ABS, e.ABS_Z)] = 255 if bit(L2) else l2
        want[(e.EV_ABS, e.ABS_RZ)] = 255 if bit(R2) else r2
        want[(e.EV_ABS, e.ABS_HAT0X)] = bit(RIGHT) - bit(LEFT)
        want[(e.EV_ABS, e.ABS_HAT0Y)] = bit(DOWN) - bit(UP)
        changed = False
        for (typ, code), v in want.items():
            if self.state.get((typ, code)) != v:
                self.ui.write(typ, code, v)
                self.state[(typ, code)] = v
                changed = True
        if changed:
            self.ui.syn()

    def neutralize(self):
        self.apply(0, 0, 0, 0, 0, 0, 0)

    def close(self):
        try:
            self.neutralize()
        finally:
            self.ui.close()


def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127."))


def uinput_help():
    if not os.path.exists("/dev/uinput"):
        return "/dev/uinput does not exist. Run: sudo modprobe uinput  (install.sh makes it permanent)"
    return ("No permission to use /dev/uinput. Run install.sh (adds the udev rule), then log out and back in.\n"
            "Quick test without installing: sudo python3 padlink-server.py")


def main():
    ap = argparse.ArgumentParser(description="PadLink phone-controller server")
    ap.add_argument("--port", type=int, default=PORT)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--name", default="Microsoft X-Box 360 pad",
                    help="device name shown to games (default matches xpad, best auto-detection)")
    ap.add_argument("--max-pads", type=int, default=4)
    ap.add_argument("--timeout", type=float, default=0.5,
                    help="seconds without packets before all inputs are released")
    ap.add_argument("--idle-remove", type=float, default=600,
                    help="seconds of silence before a virtual pad is unplugged")
    args = ap.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((args.bind, args.port))
    hostname = socket.gethostname()
    pads = {}

    def stop(*_):
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, stop)

    log(f"PadLink server on UDP {args.port}  host '{hostname}'  IP: {', '.join(local_ips()) or '?'}")
    log("Open PadLink on your phone and tap Scan (or enter the IP above).")

    try:
        while True:
            ready, _, _ = select.select([sock], [], [], 0.1)
            now = time.monotonic()
            if ready:
                data, addr = sock.recvfrom(512)
                if data.startswith(b"PSC_DISCOVER"):
                    sock.sendto(f"PSC_HERE|{hostname}".encode(), addr)
                elif data.startswith(b"PSC_PING"):
                    sock.sendto(b"PSC_PONG", addr)
                elif len(data) == PKT.size and data[:4] == b"PSC1":
                    _, cid, seq, buttons, lx, ly, rx, ry, l2, r2 = PKT.unpack(data)
                    pad = pads.get(cid)
                    if pad is None:
                        if len(pads) >= args.max_pads:
                            continue
                        used = {p.slot for p in pads.values()}
                        slot = next(i for i in range(1, args.max_pads + 1) if i not in used)
                        try:
                            pad = Pad(slot, args.name)
                        except (PermissionError, OSError) as ex:
                            log(f"Cannot create virtual pad: {ex}\n{uinput_help()}")
                            sys.exit(1)
                        pads[cid] = pad
                        log(f"Player {slot} connected from {addr[0]}")
                    # drop late/duplicate packets (unless the phone just restarted)
                    if pad.last_seq is not None and now - pad.last_rx < 1.0:
                        if seq == pad.last_seq or ((seq - pad.last_seq) & 0xFFFFFFFF) >= 0x80000000:
                            continue
                    if pad.neutral and pad.last_seq is not None and pad.addr is not None:
                        log(f"Player {pad.slot} signal back")
                    pad.last_seq, pad.last_rx, pad.addr, pad.neutral = seq, now, addr, False
                    pad.apply(buttons, lx, ly, rx, ry, l2, r2)
                elif len(data) == BYE.size and data[:4] == b"PSC0":
                    cid = BYE.unpack(data)[1]
                    pad = pads.pop(cid, None)
                    if pad:
                        pad.close()
                        log(f"Player {pad.slot} disconnected")

            for cid, pad in list(pads.items()):
                idle = now - pad.last_rx
                if idle > args.timeout and not pad.neutral:
                    pad.neutralize()
                    pad.neutral = True
                    log(f"Player {pad.slot}: no signal, inputs released")
                if idle > args.idle_remove:
                    pad.close()
                    del pads[cid]
                    log(f"Player {pad.slot} removed (idle)")
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        for pad in pads.values():
            pad.close()
        sock.close()
        log("Stopped.")


if __name__ == "__main__":
    main()
