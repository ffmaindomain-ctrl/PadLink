package com.padlink.controller

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ControllerActivity : Activity() {

    private lateinit var pad: ControllerView
    private var sender: PadSender? = null
    private var edit = false
    private var host = ""
    private val ui = Handler(Looper.getMainLooper())

    private val statusTick = object : Runnable {
        override fun run() {
            val s = sender
            if (s != null) {
                pad.statusOk = s.connected
                pad.status = when {
                    s.error != null -> "Error: ${s.error}"
                    s.connected -> "Connected to $host"
                    else -> "Waiting for PC at $host…"
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edit = intent.getBooleanExtra(EXTRA_EDIT, false)
        val prefs = Prefs.get(this)
        host = prefs.getString("host", "") ?: ""

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        pad = ControllerView(this, edit).apply {
            opacity = prefs.getInt("opacity", 85) / 100f
            haptics = prefs.getBoolean("haptics", true)
            onState = { b, lx, ly, rx, ry -> sender?.update(b, lx, ly, rx, ry) }
        }

        val root = FrameLayout(this)
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        if (edit) root.addView(editBar(), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setContentView(root)
        hideBars()
    }

    private fun editBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(200, 30, 30, 38))
            setPadding(12, 4, 12, 4)
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = TextView(this).apply {
            setTextColor(Color.rgb(255, 210, 60))
            text = "Tap a control"
            setPadding(12, 0, 16, 0)
        }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { onClick() }
        }
        val hide = btn("Hide") { pad.toggleSelectedVisible() }
        bar.addView(name)
        bar.addView(btn("−") { pad.resizeSelected(0.9f) })
        bar.addView(btn("+") { pad.resizeSelected(1.1f) })
        bar.addView(hide)
        bar.addView(btn("Reset PS2") {
            pad.controls = Layouts.ps2Default()
            Toast.makeText(this, "Default PS2 layout restored (tap Save to keep)", Toast.LENGTH_SHORT).show()
        })
        bar.addView(btn("Save") {
            Layouts.save(this, pad.controls)
            Toast.makeText(this, "Layout saved", Toast.LENGTH_SHORT).show()
            finish()
        })
        pad.onSelectionChanged = { c ->
            name.text = c?.id ?: "Tap a control"
            hide.text = if (c?.visible == false) "Show" else "Hide"
        }
        return bar
    }

    override fun onResume() {
        super.onResume()
        hideBars()
        if (!edit && host.isNotEmpty()) {
            sender = PadSender(host, Prefs.clientId(this)).also { it.start() }
            ui.post(statusTick)
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(statusTick)
        pad.releaseAll()
        // Only unplug the virtual pad on the PC when the user really leaves,
        // so switching apps briefly doesn't make the emulator lose the controller.
        sender?.stop(bye = isFinishing)
        sender = null
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    companion object {
        const val EXTRA_EDIT = "edit"
    }
}
