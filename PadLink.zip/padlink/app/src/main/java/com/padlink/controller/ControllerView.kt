package com.padlink.controller

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Draws the pad and turns multi-touch into controller state.
 * In edit mode: tap to select, drag to move, pinch to resize.
 */
class ControllerView(context: Context, private val editMode: Boolean) : View(context) {

    var controls: MutableList<Ctl> = Layouts.load(context)
        set(v) {
            field = v
            select(null)
        }
    var opacity = 0.85f
    var haptics = true
    var status = ""
        set(v) { if (field != v) { field = v; invalidate() } }
    var statusOk = false
        set(v) { if (field != v) { field = v; invalidate() } }

    /** buttons, lx, ly, rx, ry */
    var onState: ((Int, Int, Int, Int, Int) -> Unit)? = null
    var onSelectionChanged: ((Ctl?) -> Unit)? = null
    var selected: Ctl? = null
        private set

    private val ptrCtl = HashMap<Int, Ctl>()
    private val ptrBits = HashMap<Int, Int>()
    private val stickVal = HashMap<String, PointF>()
    private var buttons = 0
    private var lastState = intArrayOf(0, 0, 0, 0, 0)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val rect = RectF()
    private val arm = RectF()
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    // edit-mode drag state
    private var dragPtr = -1
    private var dragDx = 0f
    private var dragDy = 0f
    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                selected?.let {
                    it.size = (it.size * d.scaleFactor).coerceIn(0.05f, 0.7f)
                    invalidate()
                }
                return true
            }
        })

    init {
        setBackgroundColor(BG)
    }

    // ---------------------------------------------------------------- geometry

    private fun bounds(c: Ctl, out: RectF) {
        val h = height.toFloat()
        val s = c.size * h
        val bw = when (c.kind) {
            Kind.SHOULDER -> s * 2f
            Kind.SMALL -> s * 2.2f
            else -> s
        }
        val cx = c.x * width
        val cy = c.y * h
        out.set(cx - bw / 2, cy - s / 2, cx + bw / 2, cy + s / 2)
    }

    private fun isButton(c: Ctl) = c.kind == Kind.FACE || c.kind == Kind.SHOULDER || c.kind == Kind.SMALL

    private fun hit(x: Float, y: Float, filter: (Ctl) -> Boolean): Ctl? {
        var best: Ctl? = null
        var bestD = Float.MAX_VALUE
        for (c in controls) {
            if (!filter(c)) continue
            bounds(c, rect)
            val pad = min(rect.width(), rect.height()) * 0.18f
            if (x < rect.left - pad || x > rect.right + pad || y < rect.top - pad || y > rect.bottom + pad) continue
            val d = hypot(x - rect.centerX(), y - rect.centerY()) / max(rect.width(), rect.height())
            if (d < bestD) {
                bestD = d
                best = c
            }
        }
        return best
    }

    // ---------------------------------------------------------------- play input

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (editMode) return editTouch(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val x = ev.getX(i)
                val y = ev.getY(i)
                val c = hit(x, y) { it.visible }
                if (c != null) {
                    ptrCtl[ev.getPointerId(i)] = c
                    applyTouch(ev.getPointerId(i), c, x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until ev.pointerCount) {
                val id = ev.getPointerId(i)
                val x = ev.getX(i)
                val y = ev.getY(i)
                val cur = ptrCtl[id]
                if (cur == null || isButton(cur)) {
                    // buttons allow sliding from one to another (e.g. Cross -> Square)
                    val n = hit(x, y) { it.visible && isButton(it) }
                    if (n != null && n !== cur) {
                        ptrCtl[id] = n
                        applyTouch(id, n, x, y)
                    }
                } else {
                    applyTouch(id, cur, x, y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(ev.getPointerId(ev.actionIndex))
            MotionEvent.ACTION_CANCEL -> {
                ptrCtl.clear(); ptrBits.clear(); stickVal.clear()
            }
        }
        publish()
        return true
    }

    private fun applyTouch(id: Int, c: Ctl, x: Float, y: Float) {
        bounds(c, rect)
        val r = rect.width() / 2f
        val dx = (x - rect.centerX()) / r
        val dy = (y - rect.centerY()) / r
        when (c.kind) {
            Kind.STICK -> {
                val m = hypot(dx, dy)
                val k = if (m > 1f) 1f / m else 1f
                stickVal[c.id] = PointF(dx * k, dy * k)
                ptrBits.remove(id)
            }
            Kind.DPAD -> {
                var b = 0
                if (hypot(dx, dy) > 0.22f) {
                    // 0 = right, 90 = down (screen coordinates); 8 sectors of 45 degrees
                    val a = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
                    val sector = (((a + 360.0 + 22.5) % 360.0) / 45.0).toInt()
                    b = when (sector) {
                        0 -> Btn.RIGHT
                        1 -> Btn.RIGHT or Btn.DOWN
                        2 -> Btn.DOWN
                        3 -> Btn.DOWN or Btn.LEFT
                        4 -> Btn.LEFT
                        5 -> Btn.LEFT or Btn.UP
                        6 -> Btn.UP
                        else -> Btn.UP or Btn.RIGHT
                    }
                }
                ptrBits[id] = b
            }
            else -> ptrBits[id] = c.bit
        }
    }

    private fun release(id: Int) {
        val c = ptrCtl.remove(id)
        ptrBits.remove(id)
        if (c != null && c.kind == Kind.STICK) stickVal.remove(c.id)
    }

    fun releaseAll() {
        ptrCtl.clear(); ptrBits.clear(); stickVal.clear()
        publish()
    }

    private fun axis(v: Float?): Int = ((v ?: 0f) * 32767f).roundToInt().coerceIn(-32767, 32767)

    private fun publish() {
        var b = 0
        for (v in ptrBits.values) b = b or v
        val ls = stickVal["LS"]
        val rs = stickVal["RS"]
        val s = intArrayOf(b, axis(ls?.x), axis(ls?.y), axis(rs?.x), axis(rs?.y))
        if (!s.contentEquals(lastState)) {
            if (haptics && (b and buttons.inv()) != 0) buzz()
            buttons = b
            lastState = s
            onState?.invoke(s[0], s[1], s[2], s[3], s[4])
            invalidate()
        }
    }

    private fun buzz() {
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- edit input

    private fun editTouch(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = hit(ev.x, ev.y) { true }
                select(c)
                if (c != null) {
                    bounds(c, rect)
                    dragPtr = ev.getPointerId(0)
                    dragDx = ev.x - rect.centerX()
                    dragDy = ev.y - rect.centerY()
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> dragPtr = -1 // second finger = pinch, stop dragging
            MotionEvent.ACTION_MOVE -> if (dragPtr != -1 && !scaleDetector.isInProgress) {
                val i = ev.findPointerIndex(dragPtr)
                val c = selected
                if (i >= 0 && c != null) {
                    c.x = ((ev.getX(i) - dragDx) / width).coerceIn(0f, 1f)
                    c.y = ((ev.getY(i) - dragDy) / height).coerceIn(0f, 1f)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragPtr = -1
        }
        return true
    }

    fun select(c: Ctl?) {
        selected = c
        onSelectionChanged?.invoke(c)
        invalidate()
    }

    fun resizeSelected(factor: Float) {
        selected?.let { it.size = (it.size * factor).coerceIn(0.05f, 0.7f); invalidate() }
    }

    fun toggleSelectedVisible() {
        selected?.let { it.visible = !it.visible; onSelectionChanged?.invoke(it); invalidate() }
    }

    // ---------------------------------------------------------------- drawing

    private fun col(c: Int, a: Float) =
        Color.argb((Color.alpha(c) * a).roundToInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        if (editMode) drawGrid(cv)
        for (c in controls) {
            if (!c.visible && !editMode) continue
            val a = if (c.visible) opacity else 0.25f
            bounds(c, rect)
            when (c.kind) {
                Kind.FACE -> drawFace(cv, c, a)
                Kind.SHOULDER, Kind.SMALL -> drawPill(cv, c, a)
                Kind.DPAD -> drawDpad(cv, a)
                Kind.STICK -> drawStick(cv, c, a)
            }
            if (editMode && c === selected) {
                bounds(c, rect)
                rect.inset(-10f, -10f)
                stroke.color = Color.rgb(255, 210, 60)
                stroke.strokeWidth = 4f
                cv.drawRoundRect(rect, 14f, 14f, stroke)
            }
        }
        if (!editMode && status.isNotEmpty()) drawStatus(cv)
    }

    private fun drawGrid(cv: Canvas) {
        stroke.color = Color.argb(28, 255, 255, 255)
        stroke.strokeWidth = 1f
        for (i in 1 until 10) {
            val x = width * i / 10f
            val y = height * i / 10f
            cv.drawLine(x, 0f, x, height.toFloat(), stroke)
            cv.drawLine(0f, y, width.toFloat(), y, stroke)
        }
    }

    private fun drawFace(cv: Canvas, c: Ctl, a: Float) {
        val pressed = (buttons and c.bit) != 0
        val cx = rect.centerX()
        val cy = rect.centerY()
        val r = rect.width() / 2
        fill.color = col(if (pressed) PRESSED else BODY, a)
        cv.drawCircle(cx, cy, r, fill)
        stroke.strokeWidth = r * 0.07f
        stroke.color = col(EDGE, a)
        cv.drawCircle(cx, cy, r, stroke)

        val s = r * 0.45f
        stroke.strokeWidth = r * 0.12f
        when (c.bit) {
            Btn.TRIANGLE -> {
                stroke.color = col(GREEN, a)
                path.reset()
                path.moveTo(cx, cy - s)
                path.lineTo(cx + s * 0.95f, cy + s * 0.65f)
                path.lineTo(cx - s * 0.95f, cy + s * 0.65f)
                path.close()
                cv.drawPath(path, stroke)
            }
            Btn.CIRCLE -> {
                stroke.color = col(RED, a)
                cv.drawCircle(cx, cy, s * 0.85f, stroke)
            }
            Btn.CROSS -> {
                stroke.color = col(BLUE, a)
                val k = s * 0.8f
                cv.drawLine(cx - k, cy - k, cx + k, cy + k, stroke)
                cv.drawLine(cx + k, cy - k, cx - k, cy + k, stroke)
            }
            Btn.SQUARE -> {
                stroke.color = col(PINK, a)
                val k = s * 0.75f
                cv.drawRect(cx - k, cy - k, cx + k, cy + k, stroke)
            }
            else -> {
                text.color = col(LABEL, a)
                text.textSize = r * (if (c.label.length > 3) 0.34f else 0.6f)
                cv.drawText(c.label, cx, cy + text.textSize * 0.35f, text)
            }
        }
    }

    private fun drawPill(cv: Canvas, c: Ctl, a: Float) {
        val pressed = (buttons and c.bit) != 0
        val rr = rect.height() / 2
        fill.color = col(if (pressed) PRESSED else BODY, a)
        cv.drawRoundRect(rect, rr, rr, fill)
        stroke.strokeWidth = rect.height() * 0.06f
        stroke.color = col(EDGE, a)
        cv.drawRoundRect(rect, rr, rr, stroke)
        text.color = col(LABEL, a)
        text.textSize = rect.height() * (if (c.kind == Kind.SMALL) 0.38f else 0.46f)
        cv.drawText(c.label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
    }

    private fun drawDpad(cv: Canvas, a: Float) {
        val cx = rect.centerX()
        val cy = rect.centerY()
        val h = rect.width() / 2
        val t = h / 3f
        val arms = arrayOf(
            Btn.UP to floatArrayOf(cx - t, cy - h, cx + t, cy),
            Btn.DOWN to floatArrayOf(cx - t, cy, cx + t, cy + h),
            Btn.LEFT to floatArrayOf(cx - h, cy - t, cx, cy + t),
            Btn.RIGHT to floatArrayOf(cx, cy - t, cx + h, cy + t)
        )
        for ((bit, r) in arms) {
            arm.set(r[0], r[1], r[2], r[3])
            fill.color = col(if ((buttons and bit) != 0) PRESSED else BODY, a)
            cv.drawRoundRect(arm, t * 0.35f, t * 0.35f, fill)
        }
        // outline of the plus
        path.reset()
        path.moveTo(cx - t, cy - h); path.lineTo(cx + t, cy - h); path.lineTo(cx + t, cy - t)
        path.lineTo(cx + h, cy - t); path.lineTo(cx + h, cy + t); path.lineTo(cx + t, cy + t)
        path.lineTo(cx + t, cy + h); path.lineTo(cx - t, cy + h); path.lineTo(cx - t, cy + t)
        path.lineTo(cx - h, cy + t); path.lineTo(cx - h, cy - t); path.lineTo(cx - t, cy - t)
        path.close()
        stroke.strokeWidth = t * 0.12f
        stroke.color = col(EDGE, a)
        cv.drawPath(path, stroke)
        // arrows
        fill.color = col(LABEL, a)
        val e = h * 0.78f
        val w = t * 0.45f
        arrow(cv, cx, cy - e, 0f, -1f, w)
        arrow(cv, cx, cy + e, 0f, 1f, w)
        arrow(cv, cx - e, cy, -1f, 0f, w)
        arrow(cv, cx + e, cy, 1f, 0f, w)
    }

    private fun arrow(cv: Canvas, x: Float, y: Float, dx: Float, dy: Float, w: Float) {
        path.reset()
        path.moveTo(x + dx * w * 0.6f, y + dy * w * 0.6f)
        path.lineTo(x - dx * w * 0.4f + dy * w * 0.7f, y - dy * w * 0.4f + dx * w * 0.7f)
        path.lineTo(x - dx * w * 0.4f - dy * w * 0.7f, y - dy * w * 0.4f - dx * w * 0.7f)
        path.close()
        cv.drawPath(path, fill)
    }

    private fun drawStick(cv: Canvas, c: Ctl, a: Float) {
        val cx = rect.centerX()
        val cy = rect.centerY()
        val r = rect.width() / 2
        fill.color = col(STICK_BASE, a)
        cv.drawCircle(cx, cy, r, fill)
        stroke.strokeWidth = r * 0.04f
        stroke.color = col(EDGE, a)
        cv.drawCircle(cx, cy, r, stroke)
        val v = stickVal[c.id]
        val knobR = r * 0.45f
        val travel = r - knobR
        val kx = cx + (v?.x ?: 0f) * travel
        val ky = cy + (v?.y ?: 0f) * travel
        fill.color = col(if (v != null) PRESSED else KNOB, a)
        cv.drawCircle(kx, ky, knobR, fill)
        stroke.color = col(EDGE, a)
        cv.drawCircle(kx, ky, knobR, stroke)
        text.color = col(LABEL, a * 0.7f)
        text.textSize = knobR * 0.6f
        cv.drawText(c.label, kx, ky + text.textSize * 0.35f, text)
    }

    private fun drawStatus(cv: Canvas) {
        text.textSize = height * 0.032f
        text.color = Color.argb(170, 220, 220, 230)
        val y = height * 0.05f
        cv.drawText(status, width / 2f, y + text.textSize * 0.35f, text)
        val tw = text.measureText(status)
        fill.color = if (statusOk) Color.rgb(70, 210, 120) else Color.rgb(230, 80, 80)
        cv.drawCircle(width / 2f - tw / 2 - text.textSize, y, text.textSize * 0.35f, fill)
    }

    companion object {
        val BG = Color.rgb(14, 14, 18)
        val BODY = Color.rgb(36, 36, 44)
        val PRESSED = Color.rgb(85, 85, 100)
        val EDGE = Color.rgb(95, 95, 110)
        val LABEL = Color.rgb(200, 200, 210)
        val KNOB = Color.rgb(50, 50, 60)
        val STICK_BASE = Color.rgb(24, 24, 30)
        val GREEN = Color.rgb(63, 191, 127)
        val RED = Color.rgb(232, 80, 91)
        val BLUE = Color.rgb(92, 143, 230)
        val PINK = Color.rgb(224, 122, 197)
    }
}
