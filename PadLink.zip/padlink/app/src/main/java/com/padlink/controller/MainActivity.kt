package com.padlink.controller

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var hostInput: EditText
    private lateinit var found: LinearLayout
    private lateinit var scanBtn: Button
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs.get(this)
        val p = dp(18)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, p)
        }
        root.addView(text("PadLink", 30f, Color.WHITE, bold = true))
        root.addView(text(
            "PS2-style controller for your Linux PC. Start padlink-server on the PC and keep the phone " +
                    "and PC on the same Wi-Fi (or phone hotspot).", 14f, GREY
        ))

        root.addView(header("1. Find your PC"))
        scanBtn = button("Scan for PCs") { scan() }
        root.addView(scanBtn)
        found = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(found)

        root.addView(text("…or type the PC's IP address:", 14f, GREY))
        hostInput = EditText(this).apply {
            hint = "e.g. 192.168.1.20"
            setText(prefs.getString("host", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine()
        }
        root.addView(hostInput)

        root.addView(header("2. Play"))
        root.addView(button("Connect & play") { play() })
        root.addView(button("Edit layout (move / resize / hide buttons)") {
            startActivity(Intent(this, ControllerActivity::class.java).putExtra(ControllerActivity.EXTRA_EDIT, true))
        })

        root.addView(header("Settings"))
        root.addView(CheckBox(this).apply {
            text = "Vibrate on button press"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("haptics", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("haptics", on).apply() }
        })
        val opLabel = text("Button opacity: ${prefs.getInt("opacity", 85)}%", 14f, Color.WHITE)
        root.addView(opLabel)
        root.addView(SeekBar(this).apply {
            max = 90
            progress = prefs.getInt("opacity", 85) - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    opLabel.text = "Button opacity: ${v + 10}%"
                    prefs.edit().putInt("opacity", v + 10).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(ControllerView.BG)
            addView(root)
        })
        scan()
    }

    private fun scan() {
        scanBtn.isEnabled = false
        scanBtn.text = "Scanning…"
        thread(isDaemon = true) {
            val list = Discovery.scan()
            ui.post {
                if (isDestroyed) return@post
                scanBtn.isEnabled = true
                scanBtn.text = "Scan again"
                found.removeAllViews()
                if (list.isEmpty()) {
                    found.addView(text(
                        "No PC found. Check padlink-server is running and UDP port $PADLINK_PORT is open in the PC firewall.",
                        13f, Color.rgb(230, 140, 140)
                    ))
                } else for ((ip, name) in list) {
                    found.addView(button("▶  $name  ($ip)") {
                        hostInput.setText(ip)
                        play()
                    })
                }
            }
        }
    }

    private fun play() {
        val host = hostInput.text.toString().trim()
        if (host.isEmpty()) {
            Toast.makeText(this, "Scan or enter the PC's IP first", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.get(this).edit().putString("host", host).apply()
        startActivity(Intent(this, ControllerActivity::class.java))
    }

    // ---- tiny view helpers
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun header(s: String) = text(s, 18f, Color.rgb(120, 170, 255), bold = true).apply {
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    companion object {
        private val GREY = Color.rgb(170, 170, 180)
    }
}
