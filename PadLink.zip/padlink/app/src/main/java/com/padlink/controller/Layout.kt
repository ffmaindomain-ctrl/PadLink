package com.padlink.controller

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import kotlin.random.Random

/** Button bits – must match pc-server/padlink-server.py */
object Btn {
    const val CROSS = 1 shl 0
    const val CIRCLE = 1 shl 1
    const val SQUARE = 1 shl 2
    const val TRIANGLE = 1 shl 3
    const val L1 = 1 shl 4
    const val R1 = 1 shl 5
    const val L2 = 1 shl 6
    const val R2 = 1 shl 7
    const val SELECT = 1 shl 8
    const val START = 1 shl 9
    const val L3 = 1 shl 10
    const val R3 = 1 shl 11
    const val UP = 1 shl 12
    const val DOWN = 1 shl 13
    const val LEFT = 1 shl 14
    const val RIGHT = 1 shl 15
    const val ANALOG = 1 shl 16
}

enum class Kind { FACE, SHOULDER, SMALL, DPAD, STICK }

/**
 * One on-screen control. x/y are the centre as a fraction of view width/height,
 * size is a fraction of view height (diameter / height of the shape).
 */
class Ctl(
    val id: String,
    val kind: Kind,
    val bit: Int,
    val label: String,
    var x: Float,
    var y: Float,
    var size: Float,
    var visible: Boolean = true
)

object Layouts {
    private const val KEY = "layout_v1"

    /** Default PS2 (DualShock 2) layout for a landscape phone. */
    fun ps2Default(): MutableList<Ctl> = mutableListOf(
        Ctl("L2", Kind.SHOULDER, Btn.L2, "L2", 0.09f, 0.09f, 0.12f),
        Ctl("L1", Kind.SHOULDER, Btn.L1, "L1", 0.09f, 0.25f, 0.12f),
        Ctl("R2", Kind.SHOULDER, Btn.R2, "R2", 0.91f, 0.09f, 0.12f),
        Ctl("R1", Kind.SHOULDER, Btn.R1, "R1", 0.91f, 0.25f, 0.12f),
        Ctl("DPAD", Kind.DPAD, 0, "", 0.15f, 0.58f, 0.38f),
        Ctl("TRIANGLE", Kind.FACE, Btn.TRIANGLE, "TRIANGLE", 0.85f, 0.42f, 0.15f),
        Ctl("CIRCLE", Kind.FACE, Btn.CIRCLE, "CIRCLE", 0.93f, 0.58f, 0.15f),
        Ctl("CROSS", Kind.FACE, Btn.CROSS, "CROSS", 0.85f, 0.74f, 0.15f),
        Ctl("SQUARE", Kind.FACE, Btn.SQUARE, "SQUARE", 0.77f, 0.58f, 0.15f),
        Ctl("SELECT", Kind.SMALL, Btn.SELECT, "SELECT", 0.42f, 0.40f, 0.07f),
        Ctl("START", Kind.SMALL, Btn.START, "START", 0.58f, 0.40f, 0.07f),
        Ctl("ANALOG", Kind.FACE, Btn.ANALOG, "ANALOG", 0.50f, 0.56f, 0.09f),
        Ctl("LS", Kind.STICK, 0, "L", 0.36f, 0.78f, 0.32f),
        Ctl("RS", Kind.STICK, 0, "R", 0.64f, 0.78f, 0.32f),
        Ctl("L3", Kind.FACE, Btn.L3, "L3", 0.06f, 0.90f, 0.10f),
        Ctl("R3", Kind.FACE, Btn.R3, "R3", 0.94f, 0.90f, 0.10f),
    )

    fun load(ctx: Context): MutableList<Ctl> {
        val list = ps2Default()
        val raw = Prefs.get(ctx).getString(KEY, null) ?: return list
        try {
            val o = JSONObject(raw)
            for (c in list) {
                val j = o.optJSONObject(c.id) ?: continue
                c.x = j.optDouble("x", c.x.toDouble()).toFloat()
                c.y = j.optDouble("y", c.y.toDouble()).toFloat()
                c.size = j.optDouble("s", c.size.toDouble()).toFloat()
                c.visible = j.optBoolean("v", true)
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun save(ctx: Context, list: List<Ctl>) {
        val o = JSONObject()
        for (c in list) {
            o.put(c.id, JSONObject().apply {
                put("x", c.x.toDouble()); put("y", c.y.toDouble())
                put("s", c.size.toDouble()); put("v", c.visible)
            })
        }
        Prefs.get(ctx).edit().putString(KEY, o.toString()).apply()
    }
}

object Prefs {
    fun get(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("padlink", Context.MODE_PRIVATE)

    /** Stable id for this phone, so it always gets the same player slot on the PC. */
    fun clientId(ctx: Context): Int {
        val p = get(ctx)
        var id = p.getInt("client_id", 0)
        if (id == 0) {
            id = Random.nextInt(1, Int.MAX_VALUE)
            p.edit().putInt("client_id", id).apply()
        }
        return id
    }
}
