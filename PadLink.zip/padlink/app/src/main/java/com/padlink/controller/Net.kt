package com.padlink.controller

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import kotlin.concurrent.thread

const val PADLINK_PORT = 39393

/**
 * Streams controller state to the PC over UDP.
 * Packet (26 bytes, big-endian): "PSC1" | clientId u32 | seq u32 | buttons u32 |
 * lx ly rx ry i16 | l2 r2 u8. Sent on every change and at least every 50 ms.
 * One instance = one session; create a new one after stop().
 */
class PadSender(private val host: String, private val clientId: Int) {
    @Volatile private var buttons = 0
    @Volatile private var lx = 0
    @Volatile private var ly = 0
    @Volatile private var rx = 0
    @Volatile private var ry = 0
    @Volatile private var dirty = true
    @Volatile private var running = false
    @Volatile private var sendBye = false
    @Volatile var lastPong = 0L
        private set
    @Volatile var error: String? = null
        private set
    private var seq = 0

    fun update(b: Int, lx: Int, ly: Int, rx: Int, ry: Int) {
        buttons = b; this.lx = lx; this.ly = ly; this.rx = rx; this.ry = ry
        dirty = true
    }

    val connected: Boolean get() = SystemClock.uptimeMillis() - lastPong < 3000

    fun start() {
        if (running) return
        running = true
        thread(name = "padlink-tx", isDaemon = true) {
            var sock: DatagramSocket? = null
            try {
                val addr = InetAddress.getByName(host)
                val s = DatagramSocket()
                sock = s
                s.soTimeout = 400
                thread(name = "padlink-rx", isDaemon = true) { rxLoop(s) }
                val ping = "PSC_PING".toByteArray()
                var lastSend = 0L
                var lastPing = 0L
                while (running) {
                    val now = SystemClock.uptimeMillis()
                    if (dirty || now - lastSend >= 50) {
                        dirty = false
                        val p = packet()
                        s.send(DatagramPacket(p, p.size, addr, PADLINK_PORT))
                        lastSend = now
                    }
                    if (now - lastPing >= 1000) {
                        s.send(DatagramPacket(ping, ping.size, addr, PADLINK_PORT))
                        lastPing = now
                    }
                    Thread.sleep(4)
                }
                // release everything on the PC before leaving
                buttons = 0; lx = 0; ly = 0; rx = 0; ry = 0
                repeat(3) {
                    val p = packet()
                    s.send(DatagramPacket(p, p.size, addr, PADLINK_PORT))
                }
                if (sendBye) {
                    val bye = ByteBuffer.allocate(8).put("PSC0".toByteArray()).putInt(clientId).array()
                    s.send(DatagramPacket(bye, bye.size, addr, PADLINK_PORT))
                }
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            } finally {
                running = false
                sock?.close()
            }
        }
    }

    fun stop(bye: Boolean) {
        sendBye = bye
        running = false
    }

    private fun rxLoop(s: DatagramSocket) {
        val buf = ByteArray(64)
        while (!s.isClosed) {
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                if (String(p.data, 0, p.length).startsWith("PSC_PONG")) lastPong = SystemClock.uptimeMillis()
            } catch (_: SocketTimeoutException) {
            } catch (_: Exception) {
                break
            }
        }
    }

    private fun packet(): ByteArray {
        val b = buttons
        return ByteBuffer.allocate(26)
            .put("PSC1".toByteArray())
            .putInt(clientId)
            .putInt(seq++)
            .putInt(b)
            .putShort(lx.toShort()).putShort(ly.toShort())
            .putShort(rx.toShort()).putShort(ry.toShort())
            .put((if ((b and Btn.L2) != 0) 255 else 0).toByte())
            .put((if ((b and Btn.R2) != 0) 255 else 0).toByte())
            .array()
    }
}

/** Finds PCs running padlink-server on the local network (Wi-Fi or hotspot). */
object Discovery {
    fun scan(timeoutMs: Long = 1500): List<Pair<String, String>> {
        val found = LinkedHashMap<String, String>()
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                s.soTimeout = 250
                val msg = "PSC_DISCOVER".toByteArray()
                for (b in broadcastAddresses()) {
                    try { s.send(DatagramPacket(msg, msg.size, b, PADLINK_PORT)) } catch (_: Exception) {}
                }
                val end = SystemClock.uptimeMillis() + timeoutMs
                val buf = ByteArray(256)
                while (SystemClock.uptimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val t = String(p.data, 0, p.length)
                        val ip = p.address.hostAddress
                        if (t.startsWith("PSC_HERE") && ip != null) found[ip] = t.substringAfter('|', "PC")
                    } catch (_: SocketTimeoutException) {
                    }
                }
            }
        } catch (_: Exception) {
        }
        return found.map { it.key to it.value }
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    if (ia.address is Inet4Address) ia.broadcast?.let { out.add(it) }
                }
            }
        } catch (_: Exception) {
        }
        out.add(InetAddress.getByName("255.255.255.255"))
        return out.distinct()
    }
}
